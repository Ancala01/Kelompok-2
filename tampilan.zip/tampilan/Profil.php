<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Homepage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
</head>

<body>
    <!--awal navbar -->
    <nav class="navbar navbar-expand-lg bg-success navbar-dark py-10 fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="img/logo.jpg" alt="Logo" width="50" height="50" class="d-inline-block align-text-top"> Labterpadu <b>Uinril</b>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="Profil.php">Profil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Layanan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="berita.php">Berita</a>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">Silabor</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">Kontak</a>
                        </li>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- akhir navbar -->

    <!-- Awal Hero Section -->
    <section style="background: url( 'img/background.jpg') center center / cover no-repeat; position: relative; height: 60vh; display: flex; align-items: center; justify-content: center; ">
        <!-- Overlay gelap -->
        <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.6); z-index: 1; "></div>

        <!-- Konten -->
        <div style="position: relative; z-index: 2; text-align: center; color: white; padding: 0 15px; ">
            <div>
                <h1>Profil</h1>
            </div>
        </div>
    </section>
    <!-- Akhir Hero Section -->

    <!-- Hero Section -->
    <section class="hero-section">
        <h1 class="display-1 fw-bold text-white text-uppercase">Profil</h1>
    </section>

    <!-- Main Content -->
    <main class="container py-5">
        <div class="text-center mb-5">
            <!-- Ganti 'path/to/your/uin-logo.png' dengan path logo UIN yang benar -->
            <img src="path/to/your/uin-logo.png" alt="Logo UIN Raden Intan Lampung" class="uin-logo d-block mx-auto mb-4">

            <h4 class="mb-1">Ketua Lab : Dr. H. Mujib, M.Pd</h4>
            <h4 class="mb-4">Sekretaris : Aditia Fradito, M.Pd.I</h4>
        </div>

        <p class="lead text-center mb-5" style="line-height: 1.6;">
            Laboratorium Terpadu FTK UIN Raden Intan Lampung memberikan pelayanan kepada mahasiswa dan dosen untuk pelaksanaan praktikum yang menggunakan laboratorium Biologi, Fisika, Komputer, PAI, Bimbingan Konseling, dan Microteaching. Selain itu, kegiatan PPL
            (Praktik Pengalaman Lapangan) dan PPI (Praktik Pengamalan Ibadah) juga dikelola di Lab Terpadu khususnya di sekretariat Lab Terpadu.
        </p>
    </main>

    <!-- awal footer -->
    <footer class="bg-success text-white pt-4 pb-3 ">
        <div class="container text-center ">
            <p class="mb-1 ">&copy; Copyright © 2021 Universitas Islam Negeri Raden Intan Lampung, All rights reserved. </p>
            <small>Jl. Letnan Kolonel H. Endro Suratmin, Sukarame, Kota Bandar Lampung, 35131</small>
            <div class="mt-2 ">
                <a href="index.html" class="text-white me-3 text-decoration-none ">Beranda</a>
                <a href="Profil.html" class="text-white me-3 text-decoration-none ">Profil</a>
                <a href="Kontak.html " class="text-white me-3 text-decoration-none ">Kontak</a>
            </div>
        </div>
    </footer>

    <!-- akhir footer -->