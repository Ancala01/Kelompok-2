<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Homepage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" ... >
<style>
    html {
        scroll-behavior: smooth;
    }
</style>
</head>

<body>
    <!--awal navbar -->
    <nav class="navbar navbar-expand-lg bg-success navbar-dark py-10 fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="img/logo.jpg" alt="Logo" width="50" height="50" class="d-inline-block align-text-top"> Labterpadu <b>Uinril</b>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page " href="Index.php">Beranda</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link active " aria-current="page " href="Profil.php ">Profil</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link active " aria-current="page " href="Layanan.php ">Layanan</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link active " aria-current="page " href="Berita.php ">Berita</a>
                        <li class="nav-item ">
                            <a class="nav-link active " aria-current="page " href="../login_mhs/login.php ">Silabor</a>
                        </li>
                        <li class="nav-item ">
                        <a class="nav-link active " aria-current="page " href="#kontak">Kontak</a>

                        </li>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- akhir navbar -->

    <!-- Awal Hero Section -->
    <section style="background: url( 'img/background.jpg') center center / cover no-repeat; position: relative; height: 60vh; display: flex; align-items: center; justify-content: center; ">
        <!-- Overlay gelap -->
        <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.6); z-index: 1; "></div>

        <!-- Konten -->
        <div style="position: relative; z-index: 2; text-align: center; color: white; padding: 0 15px; ">
            <div>
                <h1>Selamat datang di Laboratorium Terpadu <b>Uinril</b></h1>
                <p class="lead my-4 ">
                    Laboratorium terpadu UINRIL adalah pusat layanan laboratorium terpadu untuk mendukung kegiatan praktikum, penelitian, dan pengujian. Dilengkapi fasilitas modern dan tenaga profesional, lab ini terbuka untuk mahasiswa, dosen, serta mitra eksternal yang
                    membutuhkan layanan laboratorium terpadu yang aman dan terpercaya.
                </p>
            </div>
        </div>
    </section>
    <!-- Akhir Hero Section -->




    <!-- awal card -->
    <section class="p-5 ">
        <div class="container ">
            <div class="row text-center g-4 align-items-stretch ">
                <div class="col-md ">
                    <div class="card bg-light text-dark border border-success h-100 shadow-sm hover-shadow p-4 " onmouseover="this.classList.add( 'shadow-lg') " onmouseout="this.classList.remove( 'shadow-lg') ">
                        <div class="card-body text-center ">
                            <img src="img/praktikum.png " alt="loading " width="100px ">
                            <h3 class="card-title mb-3 ">Praktikum</h3>
                            <p class="card-text ">Mahasiswa dapat mendaftar praktikum sesuai jadwal yang tersedia langsung melalui sistem online.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md ">
                    <div class="card bg-light text-dark border border-success h-100 shadow-sm hover-shadow p-4 " onmouseover="this.classList.add( 'shadow-lg') " onmouseout="this.classList.remove( 'shadow-lg') ">
                        <div class="card-body text-center ">
                            <img src="img/penelitian.png " alt="loading " width="100px ">
                            <h3 class="card-title mb-3 ">Penelitian</h3>
                            <p class="card-text ">Dosen, mahasiswa, atau mitra eksternal dapat mengajukan permohonan penggunaan lab untuk penelitian atau pengujian sampel.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md ">
                    <div class="card bg-light text-dark border border-success h-100 shadow-sm hover-shadow p-4 " onmouseover="this.classList.add( 'shadow-lg') " onmouseout="this.classList.remove( 'shadow-lg') ">
                        <div class="card-body text-center ">
                            <img src="img/parani.png " alt="loading " width="100px ">
                            <h3 class="card-title mb-3 ">Publikasi</h3>
                            <p class="card-text ">Menyediakan dokumentasi kegiatan laboratorium seperti pelatihan, seminar, workshop, dan hasil riset.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md ">
                    <div class="card bg-light text-dark border border-success h-100 shadow-sm hover-shadow p-4 " onmouseover="this.classList.add( 'shadow-lg') " onmouseout="this.classList.remove( 'shadow-lg') ">
                        <div class="card-body text-center ">
                            <img src="img/jadwal.png " alt="loading " width="100px ">
                            <h3 class="card-title mb-3 ">Jadwal</h3>
                            <p class="card-text ">Update jadwal penggunaan laboratorium, info ruangan, dan ketersediaan alat secara real-time.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- akhir card -->

    <!-- awal informasion -->
    <section>
        <div class="row align-items-center justify-content-between bg-success text-light ">
            <div class="col-md-5 ">
                <img src="img/Uinnih.png " alt=" " class="img-fluid ">
            </div>
            <div class="col-md p-5 ">
                <h2><b>Apa Itu Laboratorium Terpadu?</b></h2>
                <P>Laboratorium Terpadu adalah sebuah unit laboratorium yang menggabungkan berbagai jenis laboratorium dari berbagai jurusan atau fakultas dalam satu sistem terintegrasi. Tujuannya adalah untuk memaksimalkan penggunaan fasilitas, meningkatkan
                    efisiensi, dan mendukung kegiatan akademik serta penelitian lintas disiplin.</p>

                <p>Di UIN Raden Intan Lampung, Laboratorium Terpadu dirancang sebagai pusat layanan praktikum, riset, dan pengujian ilmiah dengan fasilitas modern dan dukungan tenaga ahli. Laboratorium ini tidak hanya melayani kebutuhan internal kampus,
                    tetapi juga terbuka untuk kerja sama eksternal seperti pengujian sampel atau penelitian bersama.</P>
            </div>
        </div>
    </section>
    <!-- akhir information -->

    <!-- Awal Artikel & Berita -->
    <section>
        <h5 class="text-center pt-5 ">Artikel & Berita</h5>
        <div class="p-5 ">
            <div class="container ">
                <div class="row row-cols-1 row-cols-md-3 g-4 ">

                    <style>
                        .card-img-top {
                            width: 100%;
                            height: 200px;
                            /* bisa disesuaikan dengan tinggi yang kamu inginkan */
                            object-fit: cover;
                            /* memastikan gambar memenuhi area tanpa distorsi */
                        }
                    </style>

                    <!-- Card 1 -->
                    <div class="col ">
                        <div class="card h-100 shadow-sm " onmouseover="this.classList.add( 'shadow-lg') " onmouseout="this.classList.remove( 'shadow-lg') ">
                            <img src="img/lab1.jpeg " class="card-img-top " alt="Artikel 1 ">
                            <div class="card-body ">
                                <h5 class="card-title ">Inovasi Teknologi Lab 2025</h5>
                                <p class="card-text ">Pengenalan alat terbaru di laboratorium yang mendukung penelitian lebih efektif.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Card 2 -->
                    <div class="col ">
                        <div class="card h-100 shadow-sm " onmouseover="this.classList.add( 'shadow-lg') " onmouseout="this.classList.remove( 'shadow-lg') ">
                            <img src="img/lab2.jpeg " class="card-img-top " alt="Artikel 2 ">
                            <div class="card-body ">
                                <h5 class="card-title ">Workshop Mikrobiologi</h5>
                                <p class="card-text ">Kegiatan pelatihan laboratorium mikrobiologi untuk mahasiswa baru.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Card 3 -->
                    <div class="col ">
                        <div class="card h-100 shadow-sm " onmouseover="this.classList.add( 'shadow-lg') " onmouseout="this.classList.remove( 'shadow-lg') ">
                            <img src="img/lab3.jpeg " class="card-img-top " alt="Artikel 3 ">
                            <div class="card-body ">
                                <h5 class="card-title ">Kolaborasi Penelitian UIN</h5>
                                <p class="card-text ">Kolaborasi antar fakultas untuk riset energi terbarukan berbasis laboratorium kampus.</p>
                            </div>
                        </div>
                    </div>


                    <!-- Card 4 -->
                    <div class="col ">
                        <div class="card h-100 shadow-sm " onmouseover="this.classList.add( 'shadow-lg') " onmouseout="this.classList.remove( 'shadow-lg') ">
                            <img src="https://unsplash.it/300/200?image=1055 " class="card-img-top " alt="Artikel 4 ">
                            <div class="card-body ">
                                <h5 class="card-title ">Safety Training Lab</h5>
                                <p class="card-text ">Pelatihan keselamatan kerja di laboratorium bagi asisten dan praktikan.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Card 5 -->
                    <div class="col ">
                        <div class="card h-100 shadow-sm " onmouseover="this.classList.add( 'shadow-lg') " onmouseout="this.classList.remove( 'shadow-lg') ">
                            <img src="https://unsplash.it/300/200?image=1060 " class="card-img-top " alt="Artikel 5 ">
                            <div class="card-body ">
                                <h5 class="card-title ">Analisis Sampel Air</h5>
                                <p class="card-text ">Hasil pengujian kualitas air sungai di sekitar lingkungan kampus.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Card 6 -->
                    <div class="col ">
                        <div class="card h-100 shadow-sm " onmouseover="this.classList.add( 'shadow-lg') " onmouseout="this.classList.remove( 'shadow-lg') ">
                            <img src="https://unsplash.it/300/200?image=1070 " class="card-img-top " alt="Artikel 6 ">
                            <div class="card-body ">
                                <h5 class="card-title ">Publikasi Ilmiah Mahasiswa</h5>
                                <p class="card-text ">Mahasiswa berhasil mempublikasikan riset laboratoriumnya di jurnal internasional.</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- akhir Artikel dan Berita -->

    <!-- awal Komen -->
    <section class="py-5 ">
        <div class="container ">
            <div class="row justify-content-center ">
                <div class="col-md-6 ">
                <h4 class="text-center mb-4" id="kontak">Hubungi Kami</h4>
                    <div class="embed-responsive embed-responsive-21by9 ">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1404.3906531339483!2d105.30369236518897!3d-5.383915193909608!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e40db5b76061255%3A0xda8d0dd733511d75!2sUniversitas%20Islam%20Negeri%20Raden%20Intan%20Lampung!5e0!3m2!1sid!2sid!4v1744550317894!5m2!1sid!2sid "
                            width="600 " height="450 " style="border:0; " allowfullscreen=" " loading="lazy " referrerpolicy="no-referrer-when-downgrade "></iframe>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- akhir komen -->
    <!-- awal footer -->
    <footer class="bg-success text-white pt-4 pb-3 ">
        <div class="container text-center ">
            <p class="mb-1 ">&copy; Copyright © 2021 Universitas Islam Negeri Raden Intan Lampung, All rights reserved. </p>
            <small>Jl. Letnan Kolonel H. Endro Suratmin, Sukarame, Kota Bandar Lampung, 35131</small>
           
        </div>
    </footer>

    <!-- akhir footer -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js " integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq " crossorigin="anonymous "></script>
</body>

</html>